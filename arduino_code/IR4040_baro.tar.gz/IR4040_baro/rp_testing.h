#ifndef __RP_TESTING_H__
#define __RP_TESTING_H__

#ifdef __cplusplus
extern "C" {
#endif

float nnpred(float[]);

#ifdef __cplusplus
}
#endif

#endif
